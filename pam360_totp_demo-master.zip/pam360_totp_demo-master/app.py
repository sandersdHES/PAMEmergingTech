from flask import Flask, render_template, request, redirect, url_for
import pyotp
import time

app = Flask(__name__)

# Hardcoded credentials
VALID_USERNAME = "admin"
VALID_PASSWORD = "pass123"
TOTP_SECRET = "JBSWY3DPEHPK3PXP"  # Base32 secret for Google Authenticator / PAM360

@app.route("/", methods=["GET", "POST"])
def login():
    error = None
    if request.method == "POST":
        username = request.form.get("username")
        password = request.form.get("password")
        totp_code = request.form.get("totp")

        totp = pyotp.TOTP(TOTP_SECRET)
        if username == VALID_USERNAME and password == VALID_PASSWORD and totp.verify(totp_code):
            return render_template("success.html")
        else:
            error = "Invalid credentials or TOTP code"

    return render_template("login.html", error=error)

if __name__ == '__main__':
    port = int(os.environ.get('PORT', 5000))
    app.run(host='0.0.0.0', port=port)
