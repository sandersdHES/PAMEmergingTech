<configuration>
  <system.webServer>
    <handlers>
      <add name="PythonHandler" path="*" verb="*" modules="FastCgiModule" scriptProcessor="D:\home\Python39\python.exe|D:\home\site\wwwroot\app.py" resourceType="Unspecified" />
    </handlers>
    <rewrite>
      <rules>
        <rule name="StaticFiles" stopProcessing="true">
          <conditions>
            <add input="{REQUEST_FILENAME}" matchType="IsFile" />
          </conditions>
          <action type="None" />
        </rule>
        <rule name="DynamicContent">
          <conditions>
            <add input="{REQUEST_FILENAME}" matchType="IsFile" negate="true" />
          </conditions>
          <action type="Rewrite" url="app.py" />
        </rule>
      </rules>
    </rewrite>
  </system.webServer>
</configuration># PAM360 TOTP Demo Web App

## Description
A simple Flask-based web application to simulate login using Username, Password, and TOTP. This can be used to test PAM360's TOTP injection functionality.

## Default Credentials
- Username: `admin`
- Password: `pass123`
- TOTP Secret: `JBSWY3DPEHPK3PXP`

Scan this TOTP secret in your authenticator app or PAM360.

## How to Run
```bash
pip install -r requirements.txt
python app.py
```

Visit `http://localhost:5000` in your browser.
